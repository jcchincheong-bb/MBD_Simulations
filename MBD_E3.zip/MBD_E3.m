%% Meta
% Author: Justin Julius Chin Cheong 34140
% Description: This script is the solution to Exercise 3
% Brandt, 2908 Multibody Dynamics
% Last Edit: 16.05.25

%% Defined Parameters
r = [2.5;1.2]; phi = 5.6723;  % Global body position [m,rad]
sA_l = [2.18;0]; sB_l = [-1.8;1.3]; % Local point displacement [m]
rd = [1;-2]; phid = 1; % Global body velocities [m/s,rad/s]
rdd = [1;-2]; phidd = 4.65; % Global body accelerations [m/s^2,rad/s^2]

%% Calculations
% Global point displacement
sA = A_matrix(phi)*sA_l; sB = A_matrix(phi)*sB_l;
sAB = sA - sB;  % relative displacement [m]

% Global point position
rA = r_Point(r,sA)
rB = r_Point(r,sB)

% Global point velocity (manual)
sAd = s_rot(sA)*phid; sBd = s_rot(sB)*phid;
rAd = rd + sAd
rBd = rd + sBd

% Global point velocity (using function r_Point_d()) 
rAd2 = r_Point_d(rd,sA,phid)
rBd2 = r_Point_d(rd,sB,phid)

% Global point accelerations (using function r_Point_dd())
rAdd = r_Point_dd(rdd,sA,phid,phidd)
rBdd = r_Point_dd(rdd,sB,phid,phidd)


